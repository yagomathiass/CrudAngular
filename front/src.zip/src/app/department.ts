export interface Department {
    name: string
    _id?: string
}
